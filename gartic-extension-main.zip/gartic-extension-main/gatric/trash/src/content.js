//short script creating script src

var script = document.createElement('script');
    script.type = 'text/javascript';
    script.src = 'https://reddap.github.io/gartic-extension/gatric/trash/src/script.js';
    document.body.appendChild(script);
