# Fakes Assistant
### Não utilize junto a extensão/script "gatric".
### About
Guiando-se por comandos via chat, esta opção irá facilitar o jogo de quem gosta de "roubar" pontos/vitórias/rank.<br>
Todas as palavras do tema **animais** serão traduzidas para outros caracteres que serão enviados para o chat.<br>

Terá partidas de 2:30~03:00 minutos; 2,700+ pontos por hora.<br>
Testando, eu fiz 15k pontos e 110 vitórias em 5 horas.
<br>

Verifique: **[a partida mais rápida do gartic](https://youtu.be/lgA8M7iCRqQ)** no YouTube.


### Usagem

<br>

```js
var script = document.createElement('script');
    script.type = 'text/javascript';
    script.src = 'https://reddap.github.io/gartic-extension/fakes%20auto-play/temptrash.js';
    document.body.appendChild(script);
```

<br>

- Você precisará colocar 5~10 contas na mesma sala com a extensão.

> Ao entrar na sala com um bot, envie "hill" no chat. Assim como deverá ser feito com cada conta.
Quando todas as contas estiverem na sala, envie "padder" para marcar a checkbox, assim começarão a jogar.

- Após isso, utilize os comandos quando for preciso.



| Comandos | Utilidade |
| :---: | :---: |
| hill | Ativar o modo bot: aparecerá a caixa ***'secreta!'*** para ativar/desativar os comandos a seguir. _(owner only)_ |
| own | Determinar-te como conta principal: irá acertar antes de outros bots. _(owner only)_|
| padder| Ativar todos os bots: marcará a caixa de todas as contas que tiverem enviado o comando "hill" |
| fvk| Desativar todos os bots: desmarcará esta caixa. |
| by!| Tirar todos os bots da sala: todos os bots **ativos** sairão da sala em até 2 segundos. |
<br>



<br>
<br>
<br>

![image](https://user-images.githubusercontent.com/70059776/146672801-c1766d3f-a458-4973-b04f-7ce7d73c9f07.png)

